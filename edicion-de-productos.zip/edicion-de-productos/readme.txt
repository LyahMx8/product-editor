=== Zalemto Product Editor Plugin ===
Contributors: Zalemto Studios
Tags: Product, woocommerce, product editor, custom purchase, WordPress Plugin
Requires at least: 4.7
Tested up to: 5.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
 
== Descripcion ==
 
Zalemto Product Editor Plugin it's a simple but powerful editor that allows you to customize any product before purchase
 
== Installation ==
1. Unpack the `download-package`.
2. Upload the file to the `/wp-content/plugins/` directory.
3. Activate the plugin through the `Plugins` menu in WordPress.
4. Done and Ready.
 
== Frequently Asked Questions ==
 
= Can I modify the plugin? =
* Yes, but you can't do it for any commercial use
 
== Screenshots ==
 
== Changelog ==
 
= 1.0 =
* Initial release